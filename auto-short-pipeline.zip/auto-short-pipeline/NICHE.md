# NICHE BRIEF — "The Last 3 Seconds"

Przeczytaj to ZANIM zaproponujesz jakikolwiek temat, skrypt albo prompt.
To jest kontrakt formatu, nie sugestia.

## Format w jednym zdaniu
Rekonstrukcja napięcia w ostatnich chwilach przed nieodwracalnym momentem
w historii/nauce — decyzją, błędem, odkryciem — zakończona twardym reveal'em
konsekwencji. Widz ma czuć zawieszenie, nie dostawać ciekawostkę.

## Rynek
Globalny, język angielski. Ton: kinowy, napięty, oszczędny w słowach.
Zero clickbaitowego przegięcia typu "YOU WON'T BELIEVE".

## Kryteria wyboru tematu (twarde filtry)
Temat ODRZUĆ jeśli:
- jest to ogólnie znany fakt bez konkretnego "punktu decyzji" (np. "Rzym
  upadł" — za ogólne, brak jednej sceny/momentu)
- był już zmiażdżony przez setki kanałów historycznych (np. zamach na
  Kennedy'ego, Titanic sam w sobie — chyba że znajdziesz kąt, którego
  nikt nie pokazał)
- nie da się skondensować do jednej sceny wizualnej (bunkier, pokój,
  laboratorium, kokpit — coś co Veo może zrekonstruować w jednym ujęciu)

Temat PRZYJMIJ jeśli ma:
- konkretną osobę, konkretne miejsce, konkretną minutę
- realną możliwość że mogło pójść inaczej (rozwidlenie historii)
- silny paradoks (np. "człowiek, który zapobiegł wojnie, nikomu o tym
  nie powiedział przez lata")

## Struktura skryptu (beats)
Każdy odcinek = 3-5 "beatów". Każdy beat to JEDNO zdanie/dwa, JEDEN klip Veo.
1. Setup (data, miejsce, kto) — beat neutralny, buduje scenę
2. Eskalacja (co się dzieje, presja czasu/decyzji)
3. Punkt bez odwrotu (moment decyzji/błędu — kulminacja napięcia)
4. Reveal (co się faktycznie stało + konsekwencja/skala)
Opcjonalnie beat 5: twist/ciekawostka dodatkowa jeśli wzmacnia zapadalność.

Długość: 25-40s total. Nie przeciągaj — każdy beat max 6-8s audio.

## Styl promptów do Veo (Flow)
Zawsze: konkretna dekada/rok w scenografii, ograniczona przestrzeń (jeden
pokój/kokpit/laboratorium), światło buduje napięcie (czerwone alarmy,
zimne leki, kontrastowe cienie), kamera się rusza subtelnie (dolly-in,
nie szybkie cięcia), 35mm film grain, cinematic thriller grading.
Unikaj: tłumów, szerokich planów, kolorowych/jasnych scen — zabija napięcie.

## Nie rób
- Nie wymyślaj faktów. Jeśli nie masz pewności co do szczegółu historycznego
  — zaznacz to i zaproponuj researching (web search), nie zgaduj.
- Nie rób z tego listy ciekawostek. Jeden odcinek = jedna scena, jedna decyzja.
- Nie kończ bez twardego reveal — brak puointy to najczęstszy powód
  że short nie działa.
