# Auto-Short Pipeline

Automatyczny montaż shortów (9:16) z gotowych klipów: selekcja najlepszych
fragmentów, beat-sync do muzyki, crop pod pion, zoom + przejścia.

## Setup

```bash
pip install -r requirements.txt
# ffmpeg musi być zainstalowany systemowo:
# mac: brew install ffmpeg | ubuntu: apt install ffmpeg
```

## Użycie

```bash
python3 main.py --clips ./clips --music ./music/track.mp3 --duration 30 --out ./output/short.mp4
```

- `./clips` — folder z gotowymi klipami `.mp4`
- `--duration` — docelowa długość finalnego shorta w sekundach
- `edit_plan.json` — powstaje po kroku scoringu, pokazuje które fragmenty
  zostały wybrane i dlaczego (score). Warto tam zajrzeć zanim zaakceptujesz render.

## Dwa tryby

**"The Last 3 Seconds" (aktywna nisza, patrz `NICHE.md`)** — Ty nie masz
gotowych klipów. Rozmawiasz z Claude Code o temacie, on researchuje i pisze
skrypt + prompty do Veo, Ty generujesz wideo ręcznie w Flow (brak API),
wrzucasz pliki do `clips/`, on składa całość z auto-voiceover (Google TTS)
i wypalonymi napisami.

```bash
export GOOGLE_APPLICATION_CREDENTIALS=/sciezka/do/klucza.json
python3 -m lib.assemble_narrated --episode episode.json --out output/odcinek.mp4
```

Setup Google TTS: włącz "Cloud Text-to-Speech API" w Google Cloud Console,
utwórz service account, pobierz klucz JSON.

**Recykling gotowych klipów (`main.py`, stary tryb)** — masz folder gotowych
klipów i chcesz z nich auto-montaż z beat-syncem do muzyki, bez skryptu/voiceover:

```bash
python3 main.py --clips ./clips --music ./music/track.mp3 --duration 30 --out ./output/short.mp4
```

## Użycie z Claude Code

Otwórz ten folder w Claude Code (przeczyta `NICHE.md` + `CLAUDE.md`) i pisz
normalnie, np.:

> Znajdź mi temat na kolejny odcinek i napisz skrypt + prompty do Veo

Claude Code sam zdecyduje którego trybu użyć i przeprowadzi Cię przez cały proces.

## Czego to NIE robi (świadomie)

- Nie generuje napisów (captions) — nie było w zakresie. Dobudować:
  Whisper (openai-whisper / faster-whisper) → SRT → ffmpeg `subtitles=` filter.
- Nie robi automatycznego doboru muzyki z biblioteki — muzykę podajesz Ty.
  Dobór "pasującego" utworu do vibe'u wymagałby osobnej analizy (Claude Vision
  na klatkach + jakiś katalog muzyki z tagami nastroju).
- Scoring "najlepszych momentów" to heurystyka audio+motion, nie rozumienie
  treści. Jeśli chcesz selekcję opartą o TREŚĆ (np. "wytnij momenty gdzie ktoś
  mówi coś zaskakującego") — trzeba dograć hook z Claude Vision/transkrypcją,
  zaznaczony w `lib/scoring.py` jako `VISION_SCORING_HOOK`.
