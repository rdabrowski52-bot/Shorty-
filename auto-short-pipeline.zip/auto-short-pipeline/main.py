"""
Auto-Short Pipeline — CLI

Przykład:
  python3 main.py --clips ./clips --music ./music/track.mp3 \
      --duration 30 --out ./output/short.mp4
"""
import argparse
import glob
import json
import os

from lib.scoring import rank_clips
from lib.beatsync import get_beat_times, build_cut_points
from lib.render import render_short


def build_edit_plan(ranked_clips: list[dict], cut_points: list[float], target_duration: float):
    """
    Rozdziela czas trwania shorta (target_duration) na tyle segmentów ile mamy
    punktów cięcia z beatów, i przypisuje im najlepsze fragmenty klipów
    (bez powtórzeń klipu, jeśli to możliwe).
    """
    n_segments = max(len(cut_points) - 1, 1)
    seg_durations = []
    for i in range(n_segments):
        start = cut_points[i]
        end = cut_points[i + 1] if i + 1 < len(cut_points) else target_duration
        seg_durations.append(max(end - start, 0.6))

    plan = []
    used_clips = set()
    pool = ranked_clips.copy()
    for seg_dur in seg_durations:
        candidate = next((c for c in pool if c["clip"] not in used_clips), pool[0])
        used_clips.add(candidate["clip"])
        c_start = candidate["start"]
        c_end = min(candidate["start"] + seg_dur, candidate["duration"])
        if c_end - c_start < seg_dur * 0.5:
            c_start = max(0.0, candidate["duration"] - seg_dur)
            c_end = candidate["duration"]
        plan.append({
            "clip": candidate["clip"],
            "start": round(c_start, 2),
            "end": round(c_end, 2),
            "score": candidate["score"],
        })
    return plan


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--clips", required=True, help="Folder z klipami wejściowymi")
    parser.add_argument("--music", required=True, help="Plik muzyczny do beat-sync")
    parser.add_argument("--duration", type=float, default=30.0, help="Docelowa długość shorta (s)")
    parser.add_argument("--out", default="./output/short.mp4")
    parser.add_argument("--exclude", nargs="*", default=[], help="Nazwy plików klipów do pominięcia")
    args = parser.parse_args()

    clip_paths = sorted(glob.glob(os.path.join(args.clips, "*.mp4")))
    clip_paths = [c for c in clip_paths if os.path.basename(c) not in args.exclude]
    if not clip_paths:
        raise SystemExit(f"Brak klipów .mp4 w {args.clips}")

    print(f"[1/4] Scoring {len(clip_paths)} klipów...")
    ranked = rank_clips(clip_paths)

    print("[2/4] Detekcja beatów w muzyce...")
    beats = get_beat_times(args.music, target_duration=args.duration)
    # zakładamy cięcie mniej więcej co 2 klipy -> licz punkty cięcia z zapasem
    approx_cuts = max(int(args.duration / 3), 2)
    cut_points = build_cut_points(beats, n_cuts=approx_cuts)
    if cut_points[-1] < args.duration:
        cut_points.append(args.duration)

    print("[3/4] Budowa edit decision list...")
    plan = build_edit_plan(ranked, cut_points, args.duration)
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    with open("edit_plan.json", "w") as f:
        json.dump({"plan": plan, "cut_points": cut_points}, f, indent=2)
    print("  -> zapisano edit_plan.json (sprawdź przed / po renderze)")

    print("[4/4] Render...")
    render_short(plan, args.music, args.out, args.duration)
    print(f"Gotowe: {args.out}")


if __name__ == "__main__":
    main()
