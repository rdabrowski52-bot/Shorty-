# Auto-Short Pipeline — instrukcja dla Claude Code

PRZECZYTAJ NAJPIERW `NICHE.md` — to jest brief formatu/niszy, nad którą
pracujemy ("The Last 3 Seconds"). Każda propozycja tematu, skryptu, promptu
do Veo musi być z nim spójna. Nie proponuj tematów bez sprawdzenia kryteriów
z NICHE.md.

## Dwa tryby pracy tego projektu — nie myl ich

**Tryb A: "Last 3 Seconds" (aktywna produkcja, użyj tego domyślnie)**
Oryginalne odcinki: research tematu → skrypt (beats wg NICHE.md) → prompty
do Veo (user generuje ręcznie w Flow) → auto voiceover (Google TTS) →
auto montaż (`lib/assemble_narrated.py`). User NIE ma jeszcze gotowych
klipów na start — to Ty (Claude Code) prowadzisz research i piszesz skrypt +
prompty, user wraca z gotowymi plikami wideo z Flow, Ty składasz całość.

Flow (Veo UI) nie ma API — user generuje wideo ręcznie, wklejając Twoje
prompty. Nie zakładaj automatycznego generowania wideo.

Workflow krok po kroku gdy user mówi "zrób mi temat/odcinek":
1. Research (web search) — znajdź temat spełniający kryteria z NICHE.md.
   Zweryfikuj fakty, nie zmyślaj szczegółów historycznych.
2. Napisz skrypt w beatach (patrz struktura w NICHE.md).
3. Dla każdego beatu napisz osobny prompt do Veo (patrz styl w NICHE.md,
   ZAWSZE po angielsku, w bloku kodu).
4. Zapisz wszystko do `episode.json` (wzór: `episode_example.json`).
5. Poczekaj aż user wrzuci wygenerowane klipy do `clips/` i zaktualizuje
   ścieżki w episode.json.
6. Uruchom: `python3 -m lib.assemble_narrated --episode episode.json --out output/nazwa.mp4`
7. Sprawdź ffprobe'em długość i czy audio/wideo się zgadzają.

**Tryb B: recykling gotowych klipów (`main.py`, stary use-case)**
Jeśli user ma FOLDER GOTOWYCH KLIPÓW (nie generuje ich pod skrypt) i chce
z nich złożyć jeden short metodą "wybierz najlepsze fragmenty + beat-sync
do muzyki" — to jest inny pipeline, użyj `main.py` (patrz niżej). NIE MIESZAJ
tych dwóch trybów — tryb B nie ma voiceover/skryptu, tylko selekcję i muzykę.

## Co masz zrobić krok po kroku
1. Sprawdź czy `ffmpeg`, `python3` i paczki z `requirements.txt` są dostępne.
   Jeśli nie — zainstaluj (`pip install -r requirements.txt`, sprawdź `ffmpeg -version`).
2. Uruchom:
   ```
   python3 main.py --clips ./clips --music ./music/track.mp3 --duration 30 --out ./output/short.mp4
   ```
3. Obejrzyj / zweryfikuj `edit_plan.json` wygenerowany w kroku scoringu —
   to jest edit decision list (które fragmenty, skąd, jak długie, gdzie cięcie).
   Jeśli user narzeka że wybrane fragmenty są słabe — NIE zgaduj, popraw wagi
   scoringu w `lib/scoring.py` (SCORE_WEIGHTS) albo dodaj ręczne wykluczenia
   klipów przez `--exclude`.
4. Jeśli render się wywali na konkretnym pliku — sprawdź kodek/rozdzielczość
   wejściowego klipu (`ffprobe`), różne źródła (telefon, OBS, TikTok download)
   mają różne piksel formaty — normalizuj przez `-pix_fmt yuv420p`.
5. Po renderze zawsze zrób szybki self-check: sprawdź długość finalnego pliku
   ffprobe'em i porównaj z `--duration`, +/- 1s tolerancji.

## Filozofia scoringu (ważne, nie olewaj tego)
"Najlepszy fragment" to nie zgadywanie na oko. Domyślnie liczymy score z:
- audio: wariancja RMS + wykrywanie peaków głośności (śmiech, krzyk, punchline)
- wideo: motion score (optical flow) — statyczne gadające głowy dostają niżej,
  gwałtowny ruch/akcja dostają wyżej
Jeśli user ma inny gust ("chcę spokojniejsze ujęcia" / "chcę tylko momenty
z twarzą w kamerę") — to jest do zmiany w `lib/scoring.py`, nie w promptach.
Rozważ dodanie scoringu przez Claude Vision (próbki klatek) jeśli heurystyki
audio/wideo nie wystarczają — patrz komentarz `VISION_SCORING_HOOK` w scoring.py.

## Nie rób
- Nie zakładaj że wszystkie klipy mają tę samą rozdzielczość/proporcje.
- Nie renderuj bez normalizacji do 1080x1920 — inaczej finalny short będzie
  miał czarne pasy albo złe crop.
- Nie ignoruj `edit_plan.json` — to jest miejsce do debugowania, nie ficzer
  do wywalenia.
