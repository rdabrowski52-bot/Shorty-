"""
Beat detection: wyciąga timestampy uderzeń z pliku muzycznego,
żeby cięcia montażu mogły lądować dokładnie na beacie.
"""
import librosa
import numpy as np


def get_beat_times(music_path: str, target_duration: float | None = None) -> list[float]:
    y, sr = librosa.load(music_path, sr=22050)
    tempo, beat_frames = librosa.beat.beat_track(y=y, sr=sr, units="frames")
    beat_times = librosa.frames_to_time(beat_frames, sr=sr).tolist()

    if target_duration is not None:
        beat_times = [t for t in beat_times if t <= target_duration]

    if not beat_times or beat_times[0] > 0.05:
        beat_times = [0.0] + beat_times
    return beat_times


def build_cut_points(beat_times: list[float], n_cuts: int, min_gap: float = 1.2) -> list[float]:
    """
    Wybiera n_cuts punktów cięcia z listy beatów, pilnując minimalnego odstępu
    (żeby nie ciąć co 0.3s tylko dlatego że tyle trwa beat przy szybkim tempie).
    """
    points = [beat_times[0]]
    for t in beat_times[1:]:
        if t - points[-1] >= min_gap:
            points.append(t)
        if len(points) >= n_cuts:
            break
    return points
