"""
Render finalnego shorta: crop 9:16, zoompan (subtelny ken burns),
xfade między segmentami, cięcia wyrównane do beatów, miks muzyki.
"""
import subprocess
import json
import os
import tempfile

TARGET_W, TARGET_H = 1080, 1920
XFADE_DUR = 0.35  # sekundy przejścia między klipami
ZOOM_AMOUNT = 1.06  # subtelny zoom, nie disco


def _normalize_segment(clip_path: str, start: float, end: float, out_path: str):
    """Wycina segment, kadruje do 9:16 (crop środka po skalowaniu), dodaje zoompan."""
    seg_dur = end - start
    fps = 30
    zoompan_frames = int(seg_dur * fps)

    vf = (
        f"scale={TARGET_W}:{TARGET_H}:force_original_aspect_ratio=increase,"
        f"crop={TARGET_W}:{TARGET_H},"
        f"zoompan=z='min(zoom+0.0008,{ZOOM_AMOUNT})':d={zoompan_frames}:"
        f"s={TARGET_W}x{TARGET_H}:fps={fps}"
    )
    subprocess.run(
        [
            "ffmpeg", "-y", "-ss", str(start), "-t", str(seg_dur), "-i", clip_path,
            "-vf", vf, "-pix_fmt", "yuv420p", "-an",
            "-r", str(fps),
            out_path,
        ],
        check=True, capture_output=True,
    )


def _concat_with_xfade(segment_paths: list[str], out_path: str):
    if len(segment_paths) == 1:
        subprocess.run(["ffmpeg", "-y", "-i", segment_paths[0], "-c", "copy", out_path],
                        check=True, capture_output=True)
        return

    inputs = []
    for p in segment_paths:
        inputs += ["-i", p]

    filter_parts = []
    durations = []
    for p in segment_paths:
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "json", p], capture_output=True, text=True, check=True,
        )
        durations.append(float(json.loads(probe.stdout)["format"]["duration"]))

    last_label = "0:v"
    offset = durations[0] - XFADE_DUR
    for i in range(1, len(segment_paths)):
        out_label = f"v{i}"
        filter_parts.append(
            f"[{last_label}][{i}:v]xfade=transition=fade:duration={XFADE_DUR}:offset={offset}[{out_label}]"
        )
        last_label = out_label
        if i < len(segment_paths) - 1:
            offset += durations[i] - XFADE_DUR

    filter_complex = ";".join(filter_parts)
    subprocess.run(
        ["ffmpeg", "-y", *inputs, "-filter_complex", filter_complex,
         "-map", f"[{last_label}]", "-pix_fmt", "yuv420p", out_path],
        check=True, capture_output=True,
    )


def render_short(edit_plan: list[dict], music_path: str, out_path: str, target_duration: float):
    tmp_dir = tempfile.mkdtemp()
    seg_paths = []
    for i, item in enumerate(edit_plan):
        seg_path = os.path.join(tmp_dir, f"seg_{i:02d}.mp4")
        _normalize_segment(item["clip"], item["start"], item["end"], seg_path)
        seg_paths.append(seg_path)

    video_no_audio = os.path.join(tmp_dir, "video_noaudio.mp4")
    _concat_with_xfade(seg_paths, video_no_audio)

    # domiksuj muzykę, przytnij do target_duration
    subprocess.run(
        [
            "ffmpeg", "-y", "-i", video_no_audio, "-i", music_path,
            "-t", str(target_duration),
            "-c:v", "copy", "-c:a", "aac", "-shortest",
            "-map", "0:v:0", "-map", "1:a:0",
            out_path,
        ],
        check=True, capture_output=True,
    )
    return out_path
