"""
Scoring klipów: ocenia każdy klip pod kątem "ile warto z niego wziąć".
Bez tego auto-montaż to losowanie, a nie selekcja najlepszych momentów.

Dwa sygnały:
  - audio_score: wariancja głośności + peaki (śmiech, krzyk, punchline, uderzenie)
  - motion_score: ile się dzieje na ekranie (optical flow), statyka = nuda

SCORE_WEIGHTS steruje balansem. Zmieniaj śmiało w zależności od gustu usera.
"""
import subprocess
import json
import numpy as np
import librosa
import cv2
import tempfile
import os

SCORE_WEIGHTS = {
    "audio": 0.6,
    "motion": 0.4,
}

# Ile sekund okna do liczenia score'u wewnątrz klipu (żeby wybrać NAJLEPSZY
# fragment klipu, a nie cały klip, jeśli klip jest długi)
WINDOW_SEC = 2.5


def _extract_audio(clip_path: str) -> str:
    tmp_wav = tempfile.mktemp(suffix=".wav")
    subprocess.run(
        ["ffmpeg", "-y", "-i", clip_path, "-vn", "-ac", "1", "-ar", "22050", tmp_wav],
        check=True, capture_output=True,
    )
    return tmp_wav


def _audio_score_curve(clip_path: str, duration: float):
    wav_path = _extract_audio(clip_path)
    try:
        y, sr = librosa.load(wav_path, sr=22050)
    finally:
        os.remove(wav_path)
    if len(y) == 0:
        return np.zeros(1), duration
    rms = librosa.feature.rms(y=y, frame_length=2048, hop_length=512)[0]
    # znormalizuj 0..1
    if rms.max() > 0:
        rms = rms / rms.max()
    times = librosa.frames_to_time(np.arange(len(rms)), sr=sr, hop_length=512)
    return rms, times


def _motion_score_curve(clip_path: str, duration: float, sample_fps: float = 4.0):
    cap = cv2.VideoCapture(clip_path)
    src_fps = cap.get(cv2.CAP_PROP_FPS) or 30
    step = max(int(src_fps / sample_fps), 1)
    prev_gray = None
    scores = []
    times = []
    frame_idx = 0
    t = 0.0
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        if frame_idx % step == 0:
            gray = cv2.cvtColor(cv2.resize(frame, (160, 90)), cv2.COLOR_BGR2GRAY)
            if prev_gray is not None:
                diff = cv2.absdiff(gray, prev_gray).astype(np.float32)
                scores.append(diff.mean())
                times.append(t)
            prev_gray = gray
        frame_idx += 1
        t = frame_idx / src_fps
    cap.release()
    if not scores:
        return np.zeros(1), np.array([0.0])
    scores = np.array(scores)
    if scores.max() > 0:
        scores = scores / scores.max()
    return scores, np.array(times)


def score_clip(clip_path: str) -> dict:
    """Zwraca najlepsze okno (start, end, score) w obrębie klipu."""
    probe = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "json", clip_path],
        capture_output=True, text=True, check=True,
    )
    duration = float(json.loads(probe.stdout)["format"]["duration"])

    audio_curve, audio_times = _audio_score_curve(clip_path, duration)
    motion_curve, motion_times = _motion_score_curve(clip_path, duration)

    # ---- VISION_SCORING_HOOK ----
    # Jeśli heurystyki audio/motion nie wystarczają (np. user chce konkretną
    # emocję na twarzy, konkretny temat w kadrze), tu jest miejsce żeby:
    #   1. wyciągnąć próbki klatek (cv2.imwrite co N sekund)
    #   2. wysłać je do Claude API (vision) z promptem oceniającym
    #   3. wymnożyć/wymieszać z audio_curve i motion_curve
    # Nie implementuj tego domyślnie — kosztuje API calls, tylko na żądanie usera.
    # -------------------------------

    n_windows = max(int(duration / WINDOW_SEC), 1)
    best = {"start": 0.0, "end": min(WINDOW_SEC, duration), "score": -1.0}
    for i in range(n_windows):
        w_start = i * WINDOW_SEC
        w_end = min(w_start + WINDOW_SEC, duration)
        a_mask = (audio_times >= w_start) & (audio_times < w_end)
        m_mask = (motion_times >= w_start) & (motion_times < w_end)
        a_val = audio_curve[a_mask].mean() if a_mask.any() else 0.0
        m_val = motion_curve[m_mask].mean() if m_mask.any() else 0.0
        score = SCORE_WEIGHTS["audio"] * a_val + SCORE_WEIGHTS["motion"] * m_val
        if score > best["score"]:
            best = {"start": round(w_start, 2), "end": round(w_end, 2), "score": round(float(score), 4)}

    return {"clip": clip_path, "duration": round(duration, 2), **best}


def rank_clips(clip_paths: list[str]) -> list[dict]:
    scored = [score_clip(c) for c in clip_paths]
    return sorted(scored, key=lambda x: x["score"], reverse=True)
